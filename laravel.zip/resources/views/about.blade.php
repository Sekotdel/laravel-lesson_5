@extends('layouts.app')

@section('title', 'О нас')

@section('menu')
    @include('menu')
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h2 class="text-center">О нас</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

